#ifndef HEADER_H
#define HEADER_H
int valorRomano(char a);
int factorial(int n);

void Problema2();
void Problema4();
void Problema6();
void Problema8();
void Problema10();
void Problema12();
void Problema14();
void Problema16();
void Problema18();

#endif // HEADER_H
