#ifndef HEADER_H
#define HEADER_H
#include <string>

std::string textoABits(const std::string& texto);

void guardarComoArchivoBinario(const std::string& bits, const std::string nombreSalida);

int metodo1(std::string nombreEntrada, std::string  nombreSalida, int n);

std::string codificarMetodo1(const std::string& binario, size_t n);

std::string decodificar1(std::string nombreEntrada, int n);

int metodo2(std::string nombreEntrada, std::string nombreSalida, int n);

std::string codificarMetodo2(const std::string& binario, size_t n);

int decodificar2(std::string nombreEntrada, int n);

std::string leerArchivo(const std::string nombreArchivo);

void guardarUsuario(const std::string archivoUsuarios, const std::string cedula, const std::string clave, int saldo, int n, int metodo);

std::string obtenerClave(const std::string usuario);

std::string obtenerSaldo(const std::string& usuario);

std::string modificarSaldo(const std::string& usuario, int cambio);

void leerArchivoBinario(const std::string& nombreArchivo);

#endif // HEADER_H
