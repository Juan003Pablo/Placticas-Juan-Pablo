#include "header.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <bitset>
using namespace std;

string textoABits(const string& texto) {
    string bits;
    for (size_t i = 0; i < texto.size(); ++i) {
        char c = texto[i];
        bits += bitset<8>(c).to_string();  // Cada carácter en 8 bits
    }
    return bits;
}

void guardarComoArchivoBinario(const string& bits, const string nombreSalida) {
    ofstream archivo(nombreSalida, ios::binary);
    for (size_t i = 0; i < bits.size(); i += 8) {
        string byte = bits.substr(i, 8);
        unsigned char valor = bitset<8>(byte).to_ulong();
        archivo.write(reinterpret_cast<char*>(&valor), sizeof(valor));
    }
    archivo.close();
}

string leerArchivo(const string nombreArchivo) {
    ifstream archivo(nombreArchivo);

    stringstream texto;
    texto << archivo.rdbuf();
    archivo.close();
    return texto.str();
}

void guardarUsuario(const string archivoUsuarios, const string cedula, const string clave, int saldo, int metodo, int n) {
    string datos = cedula + "," + clave + "," + to_string(saldo) + "\n";

    string bits = textoABits(datos);

    string codificado;
    if (metodo == 1) {
        codificado = codificarMetodo1(bits, n);
    } else if (metodo == 2) {
        codificado = codificarMetodo2(bits, n);
    } else {
        cerr << "Método no válido para codificación.\n";
        return;
    }

    ofstream archivo(archivoUsuarios, ios::binary);

    for (size_t i = 0; i < codificado.size(); i += 8) {
        string byteStr = codificado.substr(i, 8);
        unsigned char valor = bitset<8>(byteStr).to_ulong();
        archivo.write(reinterpret_cast<char*>(&valor), sizeof(valor));
    }

    archivo.close();
    cout << "Usuario guardado correctamente.\n";
}

string obtenerClave(const string usuario) {
    size_t pos1 = usuario.find(',');
    size_t pos2 = usuario.find(',', pos1 + 1);
    return usuario.substr(pos1 + 1, pos2 - pos1 - 1);
}

string obtenerSaldo(const string& usuario) {
    size_t pos1 = usuario.find(',');
    size_t pos2 = usuario.find(',', pos1 + 1);
    return usuario.substr(pos2 + 1); // Desde después de la segunda coma hasta el final
}


string modificarSaldo(const string& usuario, int cambio) {
    size_t pos2 = usuario.find(',', usuario.find(',') + 1);

    int saldo = 0;
    try {
        saldo = stoi(usuario.substr(pos2 + 1));
    } catch (const invalid_argument& e) {
        cerr << "Error: saldo no válido en la entrada del usuario.\n";
        return usuario;  // Devuelve el usuario original si falla
    } catch (const out_of_range& e) {
        cerr << "Error: el saldo es demasiado grande para un int.\n";
        return usuario;
    }

    saldo += cambio;
    return usuario.substr(0, pos2 + 1) + to_string(saldo);
}

void leerArchivoBinario(const string& nombreArchivo) {
    try {
        ifstream archivo(nombreArchivo, ios::binary);
        if (!archivo.is_open()) {
            throw runtime_error("No se pudo abrir el archivo: " + nombreArchivo);
        }

        char byte;
        while (archivo.get(byte)) {
            cout << bitset<8>(static_cast<unsigned char>(byte)) << " ";
        }

        cout << endl;
        archivo.close();
    } catch (const exception& e) {
        cerr << "Excepción capturada: " << e.what() << endl;
    }
}
