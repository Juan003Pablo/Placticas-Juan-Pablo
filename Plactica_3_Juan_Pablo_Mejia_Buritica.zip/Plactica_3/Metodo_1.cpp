#include "header.h"
#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>
using namespace std;

string invertirTodos(const string& bloque) {
    string resultado = bloque;
    for (size_t i = 0; i < resultado.size(); ++i) {
        char& bit = resultado[i];
        bit = (bit == '0') ? '1' : '0';
    }
    return resultado;
}

string invertirCada2(const string& bloque) {
    string resultado = bloque;
    for (size_t i = 0; i + 1 < bloque.size(); i += 2) {
        resultado[i] = (resultado[i]=='0')?'1':'0';
    }
    return resultado;
}

string invertirCada3(const string& bloque) {
    string resultado = bloque;
    for (size_t i = 0; i + 2 < bloque.size(); i += 3) {
        resultado[i] = (resultado[i]=='0')?'1':'0';
    }
    return resultado;
}

string codificarMetodo1(const string& binario, size_t n) {
    vector<string> bloques;
    for (size_t i = 0; i < binario.size(); i += n) {
        string bloque = binario.substr(i, n);
        bloques.push_back(bloque);
    }

    vector<string> codificados;
    for (size_t i = 0; i < bloques.size(); ++i) {
        if (i == 0) {
            codificados.push_back(invertirTodos(bloques[i]));
        } else {
            int ceros = count(bloques[i - 1].begin(), bloques[i - 1].end(), '0');
            int unos  = n - ceros;

            if (ceros == unos) {
                codificados.push_back(invertirTodos(bloques[i]));
            } else if (ceros > unos) {
                codificados.push_back(invertirCada2(bloques[i]));
            } else {
                codificados.push_back(invertirCada3(bloques[i]));
            }
        }
    }

    string resultado;
    for (const auto& bloque : codificados) {
        resultado += bloque;
    }
    return resultado;
}

int metodo1(string nombreEntrada, string  nombreSalida, int n) {

    ifstream archivo(nombreEntrada);
    if (!archivo) {
        cerr << "Error al abrir el archivo de entrada.\n";
        return 1;
    }

    string contenido((istreambuf_iterator<char>(archivo)), istreambuf_iterator<char>());
    archivo.close();

    string binario = textoABits(contenido);
    string codificado = codificarMetodo1(binario, n);

    guardarComoArchivoBinario(codificado, nombreSalida);

    cout << "Archivo codificado y guardado exitosamente en: " << nombreSalida << "\n";
    return 0;
}

string decodificar1(string nombreEntrada, int n) {
    ifstream archivo(nombreEntrada, ios::binary);
    if (!archivo.is_open()) {
        throw runtime_error("No se encotro: " + nombreEntrada);
    }

    string bits;
    unsigned char byte;
    while (archivo.read(reinterpret_cast<char*>(&byte), sizeof(byte))) {
        bits += bitset<8>(byte).to_string();
    }
    archivo.close();

    vector<string> bloquesCodificados;
    for (size_t i = 0; i < bits.size(); i += n) {
        bloquesCodificados.push_back(bits.substr(i, n));
    }

    vector<string> bloquesDecodificados;
    for (size_t i = 0; i < bloquesCodificados.size(); ++i) {
        string bloque = bloquesCodificados[i];

        if (i == 0) {
            bloquesDecodificados.push_back(invertirTodos(bloque));
        } else {
            string anteriorDecodificado = bloquesDecodificados[i - 1];
            int ceros = count(anteriorDecodificado.begin(), anteriorDecodificado.end(), '0');
            int unos = anteriorDecodificado.size() - ceros;

            if (ceros == unos) {
                bloquesDecodificados.push_back(invertirTodos(bloque));
            } else if (ceros > unos) {
                bloquesDecodificados.push_back(invertirCada2(bloque));
            } else {
                bloquesDecodificados.push_back(invertirCada3(bloque));
            }
        }
    }

    string binarioDecodificado;
    for (const auto& bloque : bloquesDecodificados) {
        binarioDecodificado += bloque;
    }

    string texto;
    for (size_t i = 0; i + 7 < binarioDecodificado.size(); i += 8) {
        string byteStr = binarioDecodificado.substr(i, 8);
        char c = static_cast<char>(bitset<8>(byteStr).to_ulong());
        texto += c;
    }

    return texto;
}
