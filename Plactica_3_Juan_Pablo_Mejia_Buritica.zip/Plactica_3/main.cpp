#include "header.h"
#include <iostream>
using namespace std;

int main()
{
    string nombreEntrada;
    string nombreSalida;
    int n;
    int opcion;
    while (true) {
        cout <<"Plactica aplicacion banco\n\n1-Entrar como administrador\n2-Entrar como usuario\n3-Probar metodos\n4-Salir"<<endl;
        cin >> opcion;
        switch (opcion) {
        case 1:
            if(decodificar1("clave_registrada_Ad",4) == leerArchivo("sudo.txt"))
            {
                cout <<"Bienvenido administrador, elija una opcion\n1-registrar un nuevo usuario\n2-salir"<<endl;
                while (true) {
                    cin >> opcion;

                    string cedula;
                    string clave;
                    int saldo;
                    switch (opcion) {
                    case 1:
                        cout <<"Ingrese la cedula del nuevo usuario"<<endl;
                        cin >> cedula;
                        cout <<"Ingrese la clave del nuevo usuario"<<endl;
                        cin >> clave;
                        cout <<"Ingrese el saldo del nuevo usuario"<<endl;
                        cin >> saldo;
                        guardarUsuario("cc" + cedula, cedula, clave, saldo, 1, 4);
                        cout <<"eliga una opcion\n1-registrar un nuevo usuario\n2-salir"<<endl;
                        break;
                    default:
                        break;
                    }
                    if(opcion != 1) break;
                }
                break;
            } else {cout << "Archivo clave no coincide con clave registrada"<<endl;}
            break;
        case 2:
            while (true) {
                string cedulaUsuario;
                string claveUsuario;
                string usuario;
                bool usuarioValido = true;

                cout <<"ingrese su cedula"<<endl;
                cin >> cedulaUsuario;
                cout <<"Ingrese su clave"<<endl;
                cin >> claveUsuario;

                try {
                usuario = decodificar1("cc" + cedulaUsuario, 4);
                } catch (const runtime_error& e) {
                    cerr << "Error: " << e.what() << endl;
                    usuarioValido = false;
                }

                if (claveUsuario == obtenerClave(usuario) && usuarioValido == true){
                    usuario = modificarSaldo(usuario,-1000);
                    int saldoUsuario;
                    int cambioSaldo;

                    cout <<"\nBienvenido usuario"<<endl;
                    while (true) {
                        cout <<"Elija una opcion\n1-Consultar dinero\n2-Retirar dinero\n3-Ingresar dinero\n4-Salir"<<endl;
                        cin >>opcion;
                        switch (opcion) {
                        case 1:
                            cout<<"-consulta de dinero-\nSu saldo es de: "<<obtenerSaldo(usuario)<<endl;
                            break;
                        case 2:
                            cout<<"-Retirar dinero-\nCuanto desea retirar?"<<endl;
                            cin >>cambioSaldo;
                            usuario = modificarSaldo(usuario,-cambioSaldo);
                            break;
                        case 3:
                            cout<<"-ingresar dinero-\nCuanto desea retirar?"<<endl;
                            cin >>cambioSaldo;
                            usuario = modificarSaldo(usuario,cambioSaldo);
                            break;
                        default:
                            break;
                        }
                        if (opcion >= 4) break;
                    }
                    saldoUsuario = stoi(obtenerSaldo(usuario));
                    guardarUsuario("cc" + cedulaUsuario, cedulaUsuario, claveUsuario, saldoUsuario, 1, 4);
                } else {cout <<"clave invalida"<<endl;}
                break;
            }
            break;
        case 3:
            cout <<"Elija el metodo de codificacion a probar\n1-Metodo 1\n2-Metodo 2"<<endl;
            cin >>opcion;
            switch (opcion) {
            case 1:
                cout <<"Metodo 1\nIngrese el nombre del archivo entrada incluyendo el .txt"<<endl;
                cin >> nombreEntrada;
                cout <<"Ingrese el nombre del archivo de salida"<<endl;
                cin >> nombreSalida;
                cout <<"Ingrese el valor de n"<<endl;
                cin >> n;
                metodo1(nombreEntrada, nombreSalida, n);
                cout <<"Archivo codificado creado"<<endl;
                cout <<"El archivo codificado es: ";
                leerArchivoBinario(nombreSalida);
                cout <<"El archivo decodificado es: "<<decodificar1(nombreSalida, n)<<endl;
                break;
            case 2:
                cout <<"Metodo 2\nIngrese el nombre del archivo entrada incluyendo el .txt"<<endl;
                cin >> nombreEntrada;
                cout <<"Ingrese el nombre del archivo de salida"<<endl;
                cin >> nombreSalida;
                cout <<"Ingrese el valor de n"<<endl;
                cin >> n;
                metodo2(nombreEntrada, nombreSalida, n);
                cout <<"Archivo codificado creado"<<endl;
                cout <<"El archivo codificado es: ";
                leerArchivoBinario(nombreSalida);
                cout <<"El archivo decodificado es: "<<decodificar2(nombreSalida, n)<<endl;
                break;
            default:
                break;
            }
            break;
        default:
            return 0;
    }
    }
    return 0;
}
