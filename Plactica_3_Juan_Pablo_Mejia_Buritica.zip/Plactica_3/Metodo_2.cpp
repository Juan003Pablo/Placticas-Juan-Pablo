#include "header.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>
using namespace std;

string codificarMetodo2(const string& binario, size_t n) {
    vector<string> bloques;
    for (size_t i = 0; i < binario.size(); i += n) {
        string bloque = binario.substr(i, n);
        bloques.push_back(bloque);
    }

    string resultado;
    for (const auto& bloque : bloques) {
        if (bloque.empty()) continue;
        // Rotación a la derecha: último bit va primero
        string rotado = bloque.back() + bloque.substr(0, bloque.size() - 1);
        resultado += rotado;
    }

    return resultado;
}

int metodo2(string nombreEntrada, string nombreSalida, int n) {
    ifstream archivo(nombreEntrada);
    if (!archivo) {
        cerr << "Error al abrir el archivo de entrada.\n";
        return 1;
    }

    string contenido((istreambuf_iterator<char>(archivo)), istreambuf_iterator<char>());
    archivo.close();

    string binario = textoABits(contenido);
    string codificado = codificarMetodo2(binario, n);

    guardarComoArchivoBinario(codificado, nombreSalida);

    cout << "Archivo codificado y guardado exitosamente en: " << nombreSalida << "\n";
    return 0;
}

string decodificarMetodo2(const string& binario, size_t n) {
    vector<string> bloques;
    for (size_t i = 0; i < binario.size(); i += n) {
        string bloque = binario.substr(i, n);
        bloques.push_back(bloque);
    }

    string resultado;
    for (const auto& bloque : bloques) {
        if (bloque.empty()) continue;
        // Rotación a la izquierda: primero se va al final
        string rotado = bloque.substr(1) + bloque[0];
        resultado += rotado;
    }

    return resultado;
}

int decodificar2(string nombreEntrada, int n) {
    ifstream archivo(nombreEntrada, ios::binary);
    if (!archivo.is_open()) {
        throw runtime_error("No se encotro: " + nombreEntrada);
    }

    string bits;
    unsigned char byte;
    while (archivo.read(reinterpret_cast<char*>(&byte), sizeof(byte))) {
        bits += bitset<8>(byte).to_string();
    }
    archivo.close();

    string binarioDecodificado = decodificarMetodo2(bits, n);

    string texto;
    for (size_t i = 0; i + 7 < binarioDecodificado.size(); i += 8) {
        string byteStr = binarioDecodificado.substr(i, 8);
        char c = static_cast<char>(bitset<8>(byteStr).to_ulong());
        texto += c;
    }
    return 0;
}
