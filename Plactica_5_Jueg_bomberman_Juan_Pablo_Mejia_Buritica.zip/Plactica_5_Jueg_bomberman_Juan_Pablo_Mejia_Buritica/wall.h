#ifndef WALL_H
#define WALL_H
#include <QGraphicsPixmapItem>

class Wall : public QGraphicsPixmapItem {
public:
    Wall();
};

class Brick : public QGraphicsPixmapItem {
public:
    Brick();
};

#endif // WALL_H
