#ifndef DOOR_H
#define DOOR_H
#include <QGraphicsPixmapItem>

class Door : public QGraphicsPixmapItem {
public:
    Door();
};

#endif // DOOR_H
