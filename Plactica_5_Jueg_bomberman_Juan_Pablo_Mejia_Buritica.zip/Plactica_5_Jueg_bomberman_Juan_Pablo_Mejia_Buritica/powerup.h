#ifndef POWERUP_H
#define POWERUP_H
#include <QGraphicsPixmapItem>

class PowerUp : public QGraphicsPixmapItem {
public:
    PowerUp();
};

#endif // POWERUP_H
